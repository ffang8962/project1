#ifndef processline_h
#define processline_h

#include <string>

void processLine(const std::string& line);

#endif
